
# tstse

<!-- badges: start -->
<!-- badges: end -->

The goal of tstse is to ...

## Installation

You can install the development version of tstse like so:

``` r
# FILL THIS IN! HOW CAN PEOPLE INSTALL YOUR DEV PACKAGE?
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(tstse)
## basic example code
```

